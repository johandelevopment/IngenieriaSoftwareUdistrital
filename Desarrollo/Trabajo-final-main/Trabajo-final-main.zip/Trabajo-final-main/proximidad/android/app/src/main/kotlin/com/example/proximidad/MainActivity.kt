package com.example.proximidad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
